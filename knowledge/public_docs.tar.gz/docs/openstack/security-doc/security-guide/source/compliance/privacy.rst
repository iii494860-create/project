=======
Privacy
=======

Privacy is an increasingly important element of a compliance program.
Businesses are being held to a higher standard by their customers, who
have increased interest in understanding how their data is treated from
a privacy perspective.

An OpenStack deployment will likely need to demonstrate compliance with
an organization's Privacy Policy, with the U.S.-E.U. Safe Harbor
framework, the ISO/IEC 29100:2011 privacy framework or with other
privacy-specific guidelines. In the U.S. the AICPA has `defined 10
privacy areas of
focus <http://www.aicpa.org/interestareas/informationtechnology/resources/privacy/generallyacceptedprivacyprinciples/>`_,
OpenStack deployments within a commercial environment may desire to
attest to some or all of these principles.

To aid OpenStack architects in the protection of personal data, we
recommend OpenStack architects review the NIST publication
800-122, titled "*Guide to Protecting the Confidentiality of Personally
Identifiable Information (PII)*." This guide steps through the process
of protecting:

   "... any information about an individual maintained by an agency,
   including (1) any information that can be used to distinguish or
   trace an individual's identity, such as name, social security
   number, date and place of birth, mother's maiden name, or biometric
   records; and (2) any other information that is linked or linkable to
   an individual, such as medical, educational, financial, and
   employment information..."

Comprehensive privacy management requires significant preparation,
thought and investment. Additional complications are introduced when
building global OpenStack clouds, for example navigating the differences
between U.S. and more restrictive E.U. privacy laws. In addition, extra
care needs to be taken when dealing with sensitive PII that may include
information such as credit card numbers or medical records. This
sensitive data is not only subject to privacy laws but also regulatory
and governmental regulations. By deferring to established best
practices, including those published by governments, a holistic privacy
management policy may be created and practiced for OpenStack
deployments.
