============
Case studies
============

Earlier in :doc:`../introduction/introduction-to-case-studies` we
introduced the Alice and Bob case studies where Alice is deploying a
private government cloud and Bob is deploying a public cloud each with
different security requirements. Here we discuss how Alice and Bob
would address configuration of the OpenStack Identity service. Alice
will be concerned with integration into the existing government
directory services, while Bob will need to provide access to the
public.

Alice's private cloud
~~~~~~~~~~~~~~~~~~~~~

Alice's enterprise has a well-established directory service with
two-factor authentication for all users. She configures the Identity
service to support an external authentication service supporting
authentication with government-issued access cards. She also uses an
external LDAP server to provide role information for the roles that are
integrated with the access control policy. Due to FedRAMP compliance
requirements, Alice implements two-factor authentication on the
management network for all administrator access.

Alice also deploys the dashboard to manage many aspects of the cloud.
She deploys the dashboard with HSTS to ensure that only HTTPS is used.
The dashboard resides within an internal subdomain of the private
network domain name system.

Alice decides to use SPICE instead of VNC for the virtual console. She
wants to take advantage of the emerging capabilities in SPICE.

Bob's public cloud
~~~~~~~~~~~~~~~~~~

Because Bob must support authentication for the general public, he
decides to use authentication based on a user name and password. He has
concerns about brute force attacks attempting to crack user passwords,
so he also uses an external authentication extension that throttles the
number of failed login attempts. Bob's management network is separate
from the other networks within his cloud, but can be reached from his
corporate network through ssh. As recommended earlier, Bob requires
administrators to use two-factor authentication on the Management
network to reduce the risk of compromised administrator passwords.

Bob also deploys the dashboard to manage many aspects of the cloud. He
deploys the dashboard with HSTS to ensure that only HTTPS is used. He
has ensured that the dashboard is deployed on a second-level domain due
to the limitations of the same-origin policy. He also disables
``HORIZON_IMAGES_ALLOW_UPLOAD`` to prevent resource exhaustion.

Bob decides to use VNC for his virtual console for its maturity and
security features.
