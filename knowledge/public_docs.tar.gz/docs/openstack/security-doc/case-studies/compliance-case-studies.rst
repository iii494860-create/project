============
Case studies
============

Earlier in :doc:`../introduction/introduction-to-case-studies`
we introduced the Alice and Bob case studies where Alice is
deploying a private government cloud and Bob is deploying a public cloud
each with different security requirements. Here we discuss how Alice and
Bob would address common compliance requirements. The preceding chapter
refers to a wide variety of compliance certifications and standards.
Alice will address compliance in a private cloud, while Bob will be
focused on compliance for a public cloud.

Alice's private cloud
~~~~~~~~~~~~~~~~~~~~~
Alice is building an OpenStack private cloud for the United States
government, specifically to provide elastic compute environments for
signal processing. Alice has researched government compliance
requirements, and has identified that her private cloud will be required
to certify against FISMA and follow the FedRAMP accreditation process,
which is required for all federal agencies, departments and contractors
to become a Certified Cloud Provider (CCP). In this particular scenario
for signal processing, the FISMA controls required will most likely be
FISMA High, which indicates possible "severe or catastrophic adverse
effects" should the information system become compromised. In addition
to FISMA Moderate controls Alice must ensure her private cloud is
FedRAMP certified, as this is a requirement for all agencies that
currently utilize, or host federal information within a cloud
environment.

To meet these strict government regulations Alice undertakes a number of
activities. Scoping of requirements is particularly important due to the
volume of controls that must be implemented, which will be defined in
NIST Publication 800-53.

As the U.S. Department of Defense is involved, Security Technical
Implementation Guides (STIGs) will come into play, which are the
configuration standards for DOD IA and IA-enabled devices and systems.
Alice notices a number of complications here as there is no STIG for
OpenStack, so she must address several underlying requirements for each
OpenStack service; for example, the networking SRG and Application SRG
will both be applicable (list of SRGs). Other critical controls include
ensuring that all identities in the cloud use PKI, that SELinux is
enabled, that encryption exists for all wire-level communications, and
that continuous monitoring is in place and clearly documented. Alice is
not concerned with object encryption, as this will be the tenant's
responsibility rather than the provider.

If Alice has adequately scoped and executed these compliance activities,
she may begin the process to become FedRAMP compliant by hiring an
approved third-party auditor. Typically this process takes up to six
months, after which she will receive an Authority to Operate and can
offer OpenStack cloud services to the government.


Bob's public cloud
~~~~~~~~~~~~~~~~~~
Bob is tasked with compliance for a new OpenStack public cloud
deployment, that is focused on providing cloud services to both small
developers and startups, as well as large enterprises. Bob recognizes
that individual developers are not necessarily concerned with compliance
certifications, but to larger enterprises certifications are critical.
Specifically Bob desires to achieve SOC 1, SOC 2 Security, as well as
ISO 27001/2 as quickly as possible. Bob references the Cloud Security
Alliance Cloud Control Matrix (CCM) to assist in identifying common
controls across these three certifications (such as periodic access
reviews, auditable logging and monitoring services, risk assessment
activities, security reviews, etc). Bob then engages an experienced
audit team to conduct a gap analysis on the public cloud deployment,
reviews the results and fills any gaps identified. Bob works with other
team members to ensure that these security controls and activities are
regularly conducted for a typical audit period (~6-12 months).

At the end of the audit period Bob has arranged for an external audit
team to review in-scope security controls at randomly sampled points of
time over a 6 month period. The audit team provides Bob with an official
report for SOC 1 and SOC 2, and separately for ISO 27001/2. As Bob has
been diligent in ensuring security controls are in place for his
OpenStack public cloud, there are no additional gaps exposed on the
report. Bob can now provide these official reports to his customers
under NDA, and advertise that he is SOC 1, SOC 2 and ISO 27001/2
compliant on his website.
